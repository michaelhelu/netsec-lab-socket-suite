#!/usr/bin/env python3
import socket
import sys

SERVER_IP = "127.0.0.1"   # Change to server IP if remote
SERVER_PORT = 5000

def main():
    try:
        client_socket = socket.socket()
        client_socket.connect((SERVER_IP, SERVER_PORT))
        print(f"Connected to {SERVER_IP}:{SERVER_PORT}\n")

        while True:
            try:
                data = client_socket.recv(4096).decode()
                if not data:
                    print("\n[!] Server closed the connection.")
                    break
                print(data, end="")  # Print without adding extra newline
                user_input = input()
                client_socket.send(user_input.encode())
            except KeyboardInterrupt:
                print("\n[!] Disconnected by user.")
                break
            except Exception as e:
                print(f"\n[!] Error: {e}")
                break

    except ConnectionRefusedError:
        print(f"[!] Cannot connect to {SERVER_IP}:{SERVER_PORT}")
    except Exception as e:
        print(f"[!] Error: {e}")
    finally:
        try:
            client_socket.close()
        except:
            pass

if __name__ == "__main__":
    main()
